const images = [
    {
        src: './images/photography/1.jpg',
        alt: '',
    },
    {
        src: './images/photography/2.jpg',
        alt: '',
    },
    {
        src: './images/photography/3.jpg',
        alt: '',
    },
    {
        src: './images/photography/4.jpg',
        alt: '',
    },
    {
        src: './images/photography/5.jpg',
        alt: '',
    },
    {
        src: './images/photography/6.jpg',
        alt: '',
    },
    {
        src: './images/photography/7.jpg',
        alt: '',
    },
    {
        src: './images/photography/8.jpg',
        alt: '',
    },
    {
        src: './images/photography/9.jpg',
        alt: '',
    },
    {
        src: './images/photography/10.jpg',
        alt: '',
    },
    {
        src: './images/photography/11.jpg',
        alt: '',
    },
    {
        src: './images/photography/12.jpg',
        alt: '',
    },
    {
        src: './images/photography/13.jpg',
        alt: '',
    },
    {
        src: './images/photography/14.jpg',
        alt: '',
    },
    {
        src: './images/photography/15.jpg',
        alt: '',
    },
    {
        src: './images/photography/16.jpg',
        alt: '',
    },
    {
        src: './images/photography/17.jpg',
        alt: '',
    },
    {
        src: './images/photography/18.jpg',
        alt: '',
    },
    {
        src: './images/photography/19.jpg',
        alt: '',
    },
    {
        src: './images/photography/20.jpg',
        alt: '',
    },
    {
        src: './images/photography/21.jpg',
        alt: '',
    },
    {
        src: './images/photography/22.jpg',
        alt: '',
    },
    {
        src: './images/photography/23.jpg',
        alt: '',
    },
    {
        src: './images/photography/24.jpg',
        alt: '',
    },
    {
        src: './images/photography/25.jpg',
        alt: '',
    },
    {
        src: './images/photography/26.jpg',
        alt: '',
    },
    {
        src: './images/photography/27.jpg',
        alt: '',
    },
    {
        src: './images/photography/28.jpg',
        alt: '',
    },
    {
        src: './images/photography/29.jpg',
        alt: '',
    },
    {
        src: './images/photography/30.jpg',
        alt: '',
    },
    {
        src: './images/photography/31.jpg',
        alt: '',
    },
    {
        src: './images/photography/32.jpg',
        alt: '',
    },
    {
        src: './images/photography/33.jpg',
        alt: '',
    },
    {
        src: './images/photography/34.jpg',
        alt: '',
    },
    {
        src: './images/photography/35.jpg',
        alt: '',
    },
    {
        src: './images/photography/36.jpg',
        alt: '',
    },
    {
        src: './images/photography/37.jpg',
        alt: '',
    },
    {
        src: './images/photography/38.jpg',
        alt: '',
    },
    {
        src: './images/photography/39.jpg',
        alt: '',
    },
    {
        src: './images/photography/40.jpg',
        alt: '',
    },
    {
        src: './images/photography/41.jpg',
        alt: '',
    },
    {
        src: './images/photography/42.jpg',
        alt: '',
    },
    {
        src: './images/photography/43.jpg',
        alt: '',
    },
    {
        src: './images/photography/44.jpg',
        alt: '',
    },
    {
        src: './images/photography/45.jpg',
        alt: '',
    },
    {
        src: './images/photography/46.jpg',
        alt: '',
    },
    {
        src: './images/photography/47.jpg',
        alt: '',
    },
    {
        src: './images/photography/48.jpg',
        alt: '',
    },
    {
        src: './images/photography/49.jpg',
        alt: '',
    },
    {
        src: './images/photography/50.jpg',
        alt: '',
    },
    {
        src: './images/photography/51.jpg',
        alt: '',
    },
    {
        src: './images/photography/52.jpg',
        alt: '',
    },
    {
        src: './images/photography/53.jpg',
        alt: '',
    },
    {
        src: './images/photography/54.jpg',
        alt: '',
    },
    {
        src: './images/photography/55.jpg',
        alt: '',
    },
    {
        src: './images/photography/56.jpg',
        alt: '',
    },
    {
        src: './images/photography/57.jpg',
        alt: '',
    },
    {
        src: './images/photography/58.jpg',
        alt: '',
    },
    {
        src: './images/photography/59.jpg',
        alt: '',
    },
    {
        src: './images/photography/60.jpg',
        alt: '',
    },
    {
        src: './images/photography/61.jpg',
        alt: '',
    },
    {
        src: './images/photography/62.jpg',
        alt: '',
    },
    {
        src: './images/photography/63.jpg',
        alt: '',
    },
    {
        src: './images/photography/64.jpg',
        alt: '',
    },
    {
        src: './images/photography/65.jpg',
        alt: '',
    },
    {
        src: './images/photography/66.jpg',
        alt: '',
    },
    {
        src: './images/photography/67.jpg',
        alt: '',
    },
    {
        src: './images/photography/68.jpg',
        alt: '',
    },
    {
        src: './images/photography/69.jpg',
        alt: '',
    },
    {
        src: './images/photography/70.jpg',
        alt: '',
    },
    {
        src: './images/photography/71.jpg',
        alt: '',
    },
    {
        src: './images/photography/72.jpg',
        alt: '',
    },
];

export default images;
