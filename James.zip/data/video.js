const video = [
    {
        preview: './video/previews/1.jpg',
        src: './video/video_1.mp4'
    },
    {
        preview: './video/previews/1.jpg',
        src: './video/video_1.mp4'
    },
    {
        preview: './video/previews/1.jpg',
        src: './video/video_1.mp4'
    },
    {
        preview: './video/previews/1.jpg',
        src: './video/video_1.mp4'
    },
];

export default video;