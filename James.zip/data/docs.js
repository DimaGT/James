const docs = [
    {
        src: './docs/james.pdf',
        title: 'Shadows in the Mist'
    },
    {
        src: './docs/james.pdf',
        title: 'Echoes of Eternity'
    },
    {
        src: './docs/james.pdf',
        title: 'The Unseen Symphony'
    },
    {
        src: './docs/james.pdf',
        title: 'Chronicles of the Lost'
    },
    {
        src: './docs/james.pdf',
        title: 'Echoes of Eternity'
    },
    {
        src: './docs/james.pdf',
        title: 'Shadows in the Mist'
    },
    {
        src: './docs/james.pdf',
        title: 'Echoes of Eternity'
    },
    {
        src: './docs/james.pdf',
        title: 'The Unseen Symphony'
    },
    {
        src: './docs/james.pdf',
        title: 'Chronicles of the Lost'
    },
    {
        src: './docs/james.pdf',
        title: 'Echoes of Eternity'
    },
];

export default docs;